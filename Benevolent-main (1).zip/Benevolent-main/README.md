# Benevolent -  
Benevolent Moon Gaming and Finance 
A team of creators with common values has galvanized from across the globe to bring the greater community innovative products that are mission-driven and community-centric in a decentralized, permissionless, trustless, smart contract catalyzed manner. 

Early in the development process, the founders of Benevolent Moon Gaming and Finance (BMGF) identified the pillars of our organizational mission.   As a team, we have an unwavering fortress of conviction that all of our contributions to the blockchain space clearly manifest these values: 
Fun and engaging support of decentralised games and financial instruments.
Global Community Focused on Community-galvanizing and ultimate community governance (DAO)
Benevolent/ Service-Oriented Vision that all of our offerings have a charitable component. 
Palpable Financial, Charitable, and Social Benefits of all gaming and financial products. 

This ReadMe outlines our initial processes, utilizing best practices of design thinking and project startup, then maps the path that we have traveled in creating, developing, growing, deploying, and nurturing the Benevolent Moon Gaming and Finance suite of decentralized products.  

Ultimately, the Benevolent Moon Squares, and its various iterations, marks the neophytic steps of a journey that we believe will be a long partnership with each other, and that our team has with the blockchain space as we pursue the ceaseless path to serve as guided by the pillars of our mission and values. 


Mission Statement Components:

Fun and engaging support of crypto growth
Global Community Focus/ Community-galvanizing
Benevolent/ Service-Oriented Vision
Financial, Charitable, Social Benefits of all our #Defi activities. 

[![built-with openzeppelin](https://img.shields.io/badge/built%20with-OpenZeppelin-3677FF)](https://docs.openzeppelin.com/)




